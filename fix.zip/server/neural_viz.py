from __future__ import annotations

import html
from typing import Iterable, Sequence


ACTION_NAMES = ["read_file", "run_test", "search_symbol", "trace_caller", "commit_location"]
FEATURE_NAMES = [
    "steps_left",
    "failed",
    "assert",
    "zerodivision",
    "error",
    "none",
    "bool_logic",
    "has_src_file",
    "explored",
    "explored_deep",
    "symbol_hit",
    "symbol_miss",
    "caller_hit",
]


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def activation_to_color(value: float, scale: float = 1.0) -> str:
    normalized = _clamp(value / max(scale, 1e-6), -1.0, 1.0)
    if normalized >= 0:
        channel = int(255 * (1 - normalized))
        return f"rgb(255,{channel},{channel})"
    channel = int(255 * (1 + normalized))
    return f"rgb({channel},{channel},255)"


def _heatmap_cells(values: Sequence[float], x: float, y: float, width: float, height: float, label: str) -> str:
    cell_width = width / max(1, len(values))
    rects = []
    for idx, value in enumerate(values):
        rects.append(
            f'<rect x="{x + idx * cell_width:.2f}" y="{y:.2f}" width="{cell_width:.2f}" '
            f'height="{height:.2f}" rx="2" fill="{activation_to_color(float(value))}">'
            f'<title>{label}[{idx}] = {float(value):.4f}</title></rect>'
        )
    return "".join(rects)


def _input_nodes(values: Sequence[float], x: float, start_y: float, gap: float, labels: Sequence[str]) -> str:
    parts = []
    for idx, (label, value) in enumerate(zip(labels, values)):
        cy = start_y + idx * gap
        parts.append(
            f'<circle cx="{x}" cy="{cy}" r="13" fill="{activation_to_color(float(value), scale=1.0)}" '
            f'stroke="rgba(255,255,255,0.35)" stroke-width="1.5">'
            f'<title>{html.escape(label)} = {float(value):.4f}</title></circle>'
        )
        parts.append(
            f'<text x="{x + 24}" y="{cy + 5}" fill="#e8edf6" font-size="12" font-family="monospace">'
            f'{html.escape(label)} <tspan fill="#93a4bd">{float(value):.3f}</tspan></text>'
        )
    return "".join(parts)


def _output_nodes(logits: Sequence[float], probs: Sequence[float], x: float, start_y: float, gap: float) -> str:
    parts = []
    for idx, (logit, prob) in enumerate(zip(logits, probs)):
        cy = start_y + idx * gap
        parts.append(
            f'<circle cx="{x}" cy="{cy}" r="18" fill="{activation_to_color(float(logit), scale=3.0)}" '
            f'stroke="rgba(255,255,255,0.4)" stroke-width="1.5">'
            f'<title>{ACTION_NAMES[idx]} logit={float(logit):.4f}, p={100 * float(prob):.2f}%</title></circle>'
        )
        parts.append(
            f'<text x="{x + 28}" y="{cy - 3}" fill="#f7fbff" font-size="12" font-family="monospace">{ACTION_NAMES[idx]}</text>'
        )
        parts.append(
            f'<text x="{x + 28}" y="{cy + 13}" fill="#ffb5a7" font-size="12" font-family="monospace">{100 * float(prob):.1f}%</text>'
        )
    return "".join(parts)


def render_neural_network_svg(
    *,
    features: Sequence[float],
    h1: Sequence[float],
    h2: Sequence[float],
    logits: Sequence[float],
    probs: Sequence[float],
    value_estimate: float = 0.0,
    step_index: int = 0,
    episode_index: int = 0,
    feature_names: Sequence[str] | None = None,
) -> str:
    labels = list(feature_names or FEATURE_NAMES)
    width = 1380
    height = 620

    return f"""
    <div style="background:linear-gradient(180deg,#08111f 0%,#04070d 100%);border:1px solid rgba(148,163,184,0.18);border-radius:20px;padding:18px;box-shadow:0 18px 60px rgba(0,0,0,0.32);">
      <style>
        .nn-fade-in {{
          animation: nnPulse 0.45s ease-out;
        }}
        @keyframes nnPulse {{
          from {{ opacity: 0.35; transform: translateY(4px); }}
          to {{ opacity: 1; transform: translateY(0); }}
        }}
      </style>
      <svg class="nn-fade-in" width="100%" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg">
        <rect width="{width}" height="{height}" rx="22" fill="#07101c"/>
        <text x="42" y="52" fill="#f8fbff" font-size="28" font-family="monospace">Actor-Critic Activation Trace</text>
        <text x="42" y="82" fill="#8ca0be" font-size="14" font-family="monospace">episode {episode_index} | step {step_index} | V(s)={value_estimate:.3f}</text>

        <text x="78" y="116" fill="#f6f8fc" font-size="16" font-family="monospace">Input features (13)</text>
        <text x="462" y="116" fill="#f6f8fc" font-size="16" font-family="monospace">Hidden 1 (64)</text>
        <text x="804" y="116" fill="#f6f8fc" font-size="16" font-family="monospace">Hidden 2 (64)</text>
        <text x="1120" y="116" fill="#f6f8fc" font-size="16" font-family="monospace">Policy output (5)</text>

        <line x1="320" y1="305" x2="430" y2="305" stroke="rgba(255,255,255,0.12)" stroke-width="2"/>
        <line x1="734" y1="305" x2="774" y2="305" stroke="rgba(255,255,255,0.12)" stroke-width="2"/>
        <line x1="1020" y1="305" x2="1084" y2="305" stroke="rgba(255,255,255,0.12)" stroke-width="2"/>

        {_input_nodes(features, 84, 146, 32, labels)}

        <rect x="430" y="164" width="260" height="282" rx="12" fill="rgba(255,255,255,0.04)" stroke="rgba(255,255,255,0.10)"/>
        {_heatmap_cells(h1, 444, 200, 232, 74, "h1")}
        <text x="444" y="300" fill="#8ca0be" font-size="12" font-family="monospace">blue = negative, white = 0, red = positive</text>
        <text x="444" y="328" fill="#8ca0be" font-size="12" font-family="monospace">tanh activations from first hidden layer</text>

        <rect x="774" y="164" width="220" height="282" rx="12" fill="rgba(255,255,255,0.04)" stroke="rgba(255,255,255,0.10)"/>
        {_heatmap_cells(h2, 788, 200, 192, 74, "h2")}
        <text x="788" y="300" fill="#8ca0be" font-size="12" font-family="monospace">second hidden layer</text>
        <text x="788" y="328" fill="#8ca0be" font-size="12" font-family="monospace">each cell is one real neuron</text>

        {_output_nodes(logits, probs, 1120, 184, 78)}

        <rect x="42" y="538" width="1296" height="38" rx="10" fill="rgba(255,255,255,0.03)" stroke="rgba(255,255,255,0.08)"/>
        <text x="56" y="562" fill="#9eb0ca" font-size="12" font-family="monospace">Inputs: {html.escape(', '.join(labels))}</text>
      </svg>
    </div>
    """
