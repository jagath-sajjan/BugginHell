from __future__ import annotations

import difflib
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import gradio as gr

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLCONFIGDIR", str(PROJECT_ROOT / ".mplconfig"))

import matplotlib
import matplotlib.pyplot as plt
import pandas as pd

matplotlib.use("Agg")

sys.path.insert(0, str(PROJECT_ROOT))

from bughunt_env import APIAgent, BugHuntEnv, RandomAgent
from bughunt_env.fixtures import get_cases
from bughunt_env.ppo_agent import ACTION_NAMES, FEATURE_NAMES, PPOTrainer, build_action
from server.code_workspace import format_codebase_for_display
from server.neural_viz import render_neural_network_svg
from server.ppo_live import run_live_ppo_training


CASE_MAP = {case.name: case for case in get_cases()}
REPLAY_PPO_TRAINER: Optional[PPOTrainer] = None


def get_replay_trainer() -> PPOTrainer:
    global REPLAY_PPO_TRAINER
    if REPLAY_PPO_TRAINER is None:
        trainer = PPOTrainer(BugHuntEnv)
        trainer.train(episodes=80)
        REPLAY_PPO_TRAINER = trainer
    return REPLAY_PPO_TRAINER


def observation_markdown(obs, *, title: str) -> str:
    history = "\n".join(f"- {item}" for item in obs.history[-6:]) or "- none"
    file_tree = "\n".join(f"- {item}" for item in obs.file_tree)
    return (
        f"### {title}\n"
        f"**steps_left**: `{obs.steps_left}`\n\n"
        f"**failing_test**: `{obs.failing_test}`\n\n"
        f"**file_tree**\n```\n{file_tree}\n```\n"
        f"**stderr**\n```text\n{obs.stderr or '<empty>'}\n```\n"
        f"**last_tool_output**\n```text\n{obs.last_tool_output or '<empty>'}\n```\n"
        f"**history**\n```text\n{history}\n```"
    )


def case_overview_markdown(case_name: str) -> str:
    case = CASE_MAP[case_name]
    return (
        f"## Case: `{case.name}`\n"
        f"**Bug summary**: {case.bug_summary}\n\n"
        f"**Ground truth**: `{case.bug_file}:{case.bug_line}`\n\n"
        f"**Failing test**: `{case.failing_test}`\n\n"
        f"**Files**\n```text\n" + "\n".join(case.file_tree) + "\n```"
    )


def case_source_bundle(case_name: str) -> str:
    return format_codebase_for_display(CASE_MAP[case_name].files)


def action_to_text(action: Tuple[int, Dict[str, Any]]) -> str:
    action_id, params = action
    return f"{ACTION_NAMES[action_id]} {params}"


def top_feature_summary(features: List[float], feature_names: List[str], limit: int = 5) -> str:
    indexed = sorted(zip(feature_names, features), key=lambda item: abs(item[1]), reverse=True)
    lines = [f"- `{name}` = `{value:.3f}`" for name, value in indexed[:limit]]
    return "\n".join(lines) or "- none"


def reward_breakdown_plot(reward_breakdown: Optional[Dict[str, Any]]):
    fig, ax = plt.subplots(figsize=(6.8, 2.4))
    if not reward_breakdown:
        ax.text(0.5, 0.5, "Reward anatomy appears after commit_location.", ha="center", va="center")
        ax.axis("off")
        fig.tight_layout()
        return fig

    labels = ["step_penalty", "file", "line", "efficiency"]
    values = [
        reward_breakdown["base_step_penalty"],
        reward_breakdown["file_score"],
        reward_breakdown["line_score"],
        reward_breakdown["efficiency_bonus_score"],
    ]
    colors = ["#d62828" if value < 0 else "#2a9d8f" for value in values]
    ax.barh(labels, values, color=colors)
    ax.axvline(0, color="#1d3557", linewidth=1)
    total = reward_breakdown["reward"]
    ax.set_title(f"Reward anatomy | total={total:.2f}")
    ax.set_xlabel("Contribution")
    for idx, value in enumerate(values):
        ax.text(value + (0.03 if value >= 0 else -0.18), idx, f"{value:+.2f}", va="center")
    fig.tight_layout()
    return fig


def observation_diff_html(before, after) -> str:
    before_text = (
        f"steps_left: {before.steps_left}\n"
        f"last_tool_output:\n{before.last_tool_output or '<empty>'}\n\n"
        f"history:\n" + ("\n".join(before.history) or "<empty>")
    )
    after_text = (
        f"steps_left: {after.steps_left}\n"
        f"last_tool_output:\n{after.last_tool_output or '<empty>'}\n\n"
        f"history:\n" + ("\n".join(after.history) or "<empty>")
    )
    diff = difflib.HtmlDiff(wrapcolumn=80).make_table(
        before_text.splitlines(),
        after_text.splitlines(),
        fromdesc="Before",
        todesc="After",
        context=True,
        numlines=2,
    )
    return (
        "<div style='background:#08111f;border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:12px;overflow:auto;'>"
        "<div style='font:600 13px monospace;color:#e6eefb;margin-bottom:8px;'>Observation diff</div>"
        f"{diff}</div>"
    )


def blank_diff_html() -> str:
    return (
        "<div style='background:#08111f;border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:12px;'>"
        "<div style='font:600 13px monospace;color:#e6eefb;'>Observation diff</div>"
        "<div style='font:13px monospace;color:#9fb3c8;margin-top:8px;'>No action has executed yet.</div>"
        "</div>"
    )


def blank_neural_note(message: str) -> str:
    return (
        "<div style='background:linear-gradient(180deg,#08111f 0%,#04070d 100%);border:1px solid rgba(148,163,184,0.18);"
        "border-radius:20px;padding:18px;color:#dbe7f6;font:14px monospace;'>"
        f"{message}</div>"
    )


def make_agent_session(agent_kind: str, case_name: str) -> Dict[str, Any]:
    env = BugHuntEnv(seed=1)
    obs, info = env.reset(seed=1, options={"case_name": case_name})
    if agent_kind == "random":
        helper = RandomAgent()
    elif agent_kind == "api":
        helper = APIAgent()
    else:
        helper = get_replay_trainer()
    session = {
        "kind": agent_kind,
        "env": env,
        "obs": obs,
        "info": info,
        "helper": helper,
        "done": False,
        "step_index": 0,
        "last_transition": None,
        "next_decision": None,
    }
    session["next_decision"] = plan_decision(session)
    return session


def plan_decision(session: Dict[str, Any]) -> Dict[str, Any]:
    obs = session["obs"]
    if session["done"]:
        return {"action": None, "reason": "Episode finished.", "viz_html": blank_neural_note("Episode finished."), "inspection": None}

    if session["kind"] == "random":
        action = session["helper"].act(obs)
        return {
            "action": action,
            "reason": "Uniform random baseline. No stateful policy; this step is sampled at random.",
            "viz_html": blank_neural_note("Random baseline has no internal neural activations to render."),
            "inspection": None,
        }

    if session["kind"] == "api":
        decision = session["helper"].decide(obs)
        reason = "API LLM decision.\n"
        if decision.parse_error:
            reason += f"\nFallback triggered: `{decision.parse_error}`"
        reason += f"\n\nRaw response:\n```json\n{decision.raw_response or '<empty>'}\n```"
        return {
            "action": decision.action,
            "reason": reason,
            "viz_html": blank_neural_note("Qwen runs remotely through the Hack Club API; token-level activations are not exposed by the endpoint."),
            "inspection": None,
        }

    trainer = session["helper"]
    inspection = trainer.model.inspect(obs)
    action_id = inspection["suggested_action_id"]
    action = build_action(action_id, obs)
    reason = (
        f"Top policy action: `{ACTION_NAMES[action_id]}`\n\n"
        f"Top features:\n{top_feature_summary(inspection['features'], inspection['feature_names'])}\n\n"
        f"Feature vector:\n```text\n"
        + ", ".join(f"{name}={value:.3f}" for name, value in zip(inspection["feature_names"], inspection["features"]))
        + "\n```"
    )
    viz_html = render_neural_network_svg(
        features=inspection["features"],
        h1=inspection["h1"],
        h2=inspection["h2"],
        logits=inspection["logits"],
        probs=inspection["probs"],
        value_estimate=inspection["value"],
        step_index=session["step_index"],
        episode_index=0,
        feature_names=inspection["feature_names"],
    )
    return {
        "action": action,
        "reason": reason,
        "viz_html": viz_html,
        "inspection": inspection,
    }


def step_agent_session(session: Dict[str, Any]) -> Dict[str, Any]:
    if session["done"]:
        return session

    before = session["obs"]
    decision = session["next_decision"] or plan_decision(session)
    action = decision["action"]
    after, reward, terminated, truncated, info = session["env"].step(action)
    session["obs"] = after
    session["info"] = info
    session["done"] = bool(terminated or truncated)
    session["step_index"] += 1
    session["last_transition"] = {
        "before": before,
        "after": after,
        "action": action,
        "reward": reward,
        "info": info,
        "decision": decision,
    }
    session["next_decision"] = plan_decision(session)
    return session


def render_agent_outputs(session: Dict[str, Any]) -> Tuple[str, str, str, Any, str]:
    label = {"ppo": "PPO agent", "random": "Random agent", "api": "API LLM agent"}[session["kind"]]
    obs_md = observation_markdown(session["obs"], title=label)

    last = session["last_transition"]
    next_decision = session["next_decision"]
    if last:
        reward_breakdown = last["info"].get("reward_breakdown")
        action_md = (
            f"### Action trace\n"
            f"**executed**: `{action_to_text(last['action'])}`\n\n"
            f"**reward**: `{last['reward']:.3f}`\n\n"
            f"**reasoning**\n{last['decision']['reason']}\n\n"
            f"**next**: `{action_to_text(next_decision['action']) if next_decision['action'] else 'episode finished'}`"
        )
        diff_html = observation_diff_html(last["before"], last["after"])
        reward_plot = reward_breakdown_plot(reward_breakdown)
    else:
        action_md = (
            f"### Action preview\n"
            f"**next**: `{action_to_text(next_decision['action']) if next_decision['action'] else 'episode finished'}`\n\n"
            f"**reasoning**\n{next_decision['reason']}"
        )
        diff_html = blank_diff_html()
        reward_plot = reward_breakdown_plot(None)

    viz_html = next_decision["viz_html"]
    return obs_md, action_md, viz_html, reward_plot, diff_html


def render_live_outputs(state: Dict[str, Any]):
    outputs: List[Any] = [state, case_overview_markdown(state["case_name"]), case_source_bundle(state["case_name"])]
    for key in ["ppo", "random", "api"]:
        outputs.extend(render_agent_outputs(state["agents"][key]))
    return outputs


def init_live_episode(case_name: str):
    state = {
        "case_name": case_name,
        "agents": {
            "ppo": make_agent_session("ppo", case_name),
            "random": make_agent_session("random", case_name),
            "api": make_agent_session("api", case_name),
        },
    }
    return render_live_outputs(state)


def step_live_episode(state: Optional[Dict[str, Any]], case_name: str):
    if not state or state.get("case_name") != case_name:
        state = {
            "case_name": case_name,
            "agents": {
                "ppo": make_agent_session("ppo", case_name),
                "random": make_agent_session("random", case_name),
                "api": make_agent_session("api", case_name),
            },
        }
    for key in ["ppo", "random", "api"]:
        state["agents"][key] = step_agent_session(state["agents"][key])
    return render_live_outputs(state)


def run_full_episode(state: Optional[Dict[str, Any]], case_name: str):
    if not state or state.get("case_name") != case_name:
        state = init_live_episode(case_name)[0]
    active = True
    while active:
        active = False
        for key in ["ppo", "random", "api"]:
            if not state["agents"][key]["done"]:
                state["agents"][key] = step_agent_session(state["agents"][key])
                active = True
        yield render_live_outputs(state)
        if active:
            time.sleep(0.5)


def run_text_episode(agent_kind: str, case_name: str) -> str:
    session = make_agent_session(agent_kind, case_name)
    lines = [f"Case: {case_name}", f"Agent: {agent_kind}"]
    while not session["done"]:
        session = step_agent_session(session)
        step = session["last_transition"]
        lines.append(
            f"step={session['step_index']} action={action_to_text(step['action'])} "
            f"reward={step['reward']:.3f} done={session['done']}"
        )
        lines.append(step["after"].last_tool_output)
        lines.append("-" * 88)
    return "\n".join(lines)


CUSTOM_CSS = """
body { background: radial-gradient(circle at top, #132238 0%, #060a11 45%, #020407 100%); }
.gradio-container { max-width: 1700px !important; }
.panel h3, .panel p, .panel li, .panel code { color: #e6eefb; }
table.diff { font-family: monospace; font-size: 12px; color: #dbe7f6; width: 100%; }
table.diff td, table.diff th { padding: 4px 6px; }
.diff_add { background: rgba(42,157,143,0.24); }
.diff_sub { background: rgba(214,40,40,0.24); }
"""


with gr.Blocks() as app:
    gr.Markdown("# BugginHell Naked RL Lab")

    live_state = gr.State(None)

    with gr.Tab("Live Episode"):
        with gr.Row():
            case_dropdown = gr.Dropdown(
                choices=sorted(CASE_MAP.keys()),
                value=sorted(CASE_MAP.keys())[0],
                label="Bug case",
            )
            init_btn = gr.Button("Load Case")
            step_btn = gr.Button("Step →")
            run_btn = gr.Button("Run Full Episode")

        case_overview = gr.Markdown()
        case_code = gr.Code(label="Fixture source bundle", language="python", lines=18)

        with gr.Row():
            ppo_obs = gr.Markdown(elem_classes=["panel"])
            rand_obs = gr.Markdown(elem_classes=["panel"])
            api_obs = gr.Markdown(elem_classes=["panel"])

        with gr.Row():
            ppo_action = gr.Markdown(elem_classes=["panel"])
            rand_action = gr.Markdown(elem_classes=["panel"])
            api_action = gr.Markdown(elem_classes=["panel"])

        with gr.Row():
            ppo_viz = gr.HTML()
            rand_viz = gr.HTML()
            api_viz = gr.HTML()

        with gr.Row():
            ppo_reward = gr.Plot(label="PPO reward anatomy")
            rand_reward = gr.Plot(label="Random reward anatomy")
            api_reward = gr.Plot(label="API LLM reward anatomy")

        with gr.Row():
            ppo_diff = gr.HTML()
            rand_diff = gr.HTML()
            api_diff = gr.HTML()

        live_outputs = [
            live_state,
            case_overview,
            case_code,
            ppo_obs,
            ppo_action,
            ppo_viz,
            ppo_reward,
            ppo_diff,
            rand_obs,
            rand_action,
            rand_viz,
            rand_reward,
            rand_diff,
            api_obs,
            api_action,
            api_viz,
            api_reward,
            api_diff,
        ]

        init_btn.click(fn=init_live_episode, inputs=[case_dropdown], outputs=live_outputs)
        step_btn.click(fn=step_live_episode, inputs=[live_state, case_dropdown], outputs=live_outputs)
        run_btn.click(fn=run_full_episode, inputs=[live_state, case_dropdown], outputs=live_outputs)

    with gr.Tab("Live RL Dashboard"):
        gr.Markdown("Train PPO live and stream real metrics after each episode.")
        episodes = gr.Slider(minimum=5, maximum=100, value=25, step=5, label="Episodes")
        ppo_btn = gr.Button("Run Live PPO")

        training_log = gr.Textbox(label="Training log", lines=18)
        metrics_table = gr.Dataframe(label="Episode metrics")

        with gr.Row():
            reward_plot = gr.Plot(label="Reward curve")
            loss_plot = gr.Plot(label="Loss curve")

        with gr.Row():
            success_plot = gr.Plot(label="Rolling success rate")
            action_plot = gr.Plot(label="Action distribution")

        with gr.Row():
            entropy_plot = gr.Plot(label="Policy entropy")
            heatmap_plot = gr.Plot(label="Case x action heatmap")

        ppo_btn.click(
            fn=run_live_ppo_training,
            inputs=[episodes],
            outputs=[
                training_log,
                metrics_table,
                reward_plot,
                loss_plot,
                success_plot,
                action_plot,
                entropy_plot,
                heatmap_plot,
            ],
        )

    with gr.Tab("Agent Comparison"):
        compare_case = gr.Dropdown(
            choices=sorted(CASE_MAP.keys()),
            value=sorted(CASE_MAP.keys())[0],
            label="Bug case",
        )
        compare_btn = gr.Button("Run Full Text Comparison")
        with gr.Row():
            random_text = gr.Textbox(label="Random", lines=20)
            ppo_text = gr.Textbox(label="PPO", lines=20)
            api_text = gr.Textbox(label="API LLM", lines=20)

        compare_btn.click(
            fn=lambda case_name: (
                run_text_episode("random", case_name),
                run_text_episode("ppo", case_name),
                run_text_episode("api", case_name),
            ),
            inputs=[compare_case],
            outputs=[random_text, ppo_text, api_text],
        )

app.queue()
app.css = CUSTOM_CSS


if __name__ == "__main__":
    app.launch()
